# raijin-labs-lucid-ai

Developer-friendly & type-safe Typescript SDK specifically catered to leverage *raijin-labs-lucid-ai* API.

[![Built by Speakeasy](https://img.shields.io/badge/Built_by-SPEAKEASY-374151?style=for-the-badge&labelColor=f3f4f6)](https://www.speakeasy.com/?utm_source=raijin-labs-lucid-ai&utm_campaign=typescript)
[![License: MIT](https://img.shields.io/badge/LICENSE_//_MIT-3b5bdb?style=for-the-badge&labelColor=eff6ff)](https://opensource.org/licenses/MIT)


<br /><br />
> [!IMPORTANT]
> This SDK is not yet ready for production use. To complete setup please follow the steps outlined in your [workspace](https://app.speakeasy.com/org/raijin-labs-gc4/lucid). Delete this section before > publishing to a package manager.

<!-- Start Summary [summary] -->
## Summary

LucidLayer API: LucidLayer Offchain API.

This OpenAPI spec is used to generate SDK clients.
<!-- End Summary [summary] -->

<!-- Start Table of Contents [toc] -->
## Table of Contents
<!-- $toc-max-depth=2 -->
* [raijin-labs-lucid-ai](#raijin-labs-lucid-ai)
  * [SDK Installation](#sdk-installation)
  * [Requirements](#requirements)
  * [SDK Example Usage](#sdk-example-usage)
  * [Available Resources and Operations](#available-resources-and-operations)
  * [Standalone functions](#standalone-functions)
  * [Retries](#retries)
  * [Error Handling](#error-handling)
  * [Server Selection](#server-selection)
  * [Custom HTTP Client](#custom-http-client)
  * [Debugging](#debugging)
* [Development](#development)
  * [Maturity](#maturity)
  * [Contributions](#contributions)

<!-- End Table of Contents [toc] -->

<!-- Start SDK Installation [installation] -->
## SDK Installation

> [!TIP]
> To finish publishing your SDK to npm and others you must [run your first generation action](https://www.speakeasy.com/docs/github-setup#step-by-step-guide).


The SDK can be installed with either [npm](https://www.npmjs.com/), [pnpm](https://pnpm.io/), [bun](https://bun.sh/) or [yarn](https://classic.yarnpkg.com/en/) package managers.

### NPM

```bash
npm add <UNSET>
```

### PNPM

```bash
pnpm add <UNSET>
```

### Bun

```bash
bun add <UNSET>
```

### Yarn

```bash
yarn add <UNSET>
```

> [!NOTE]
> This package is published with CommonJS and ES Modules (ESM) support.
<!-- End SDK Installation [installation] -->

<!-- Start Requirements [requirements] -->
## Requirements

For supported JavaScript runtimes, please consult [RUNTIMES.md](RUNTIMES.md).
<!-- End Requirements [requirements] -->

<!-- Start SDK Example Usage [usage] -->
## SDK Example Usage

### Example

```typescript
import { RaijinLabsLucidAi } from "raijin-labs-lucid-ai";

const raijinLabsLucidAi = new RaijinLabsLucidAi();

async function run() {
  const result = await raijinLabsLucidAi.passports.lucidCreatePassport({
    type: "dataset",
    owner: "<value>",
    metadata: {
      "key": "<value>",
      "key1": "<value>",
      "key2": "<value>",
    },
  });

  console.log(result);
}

run();

```
<!-- End SDK Example Usage [usage] -->

<!-- Start Available Resources and Operations [operations] -->
## Available Resources and Operations

<details open>
<summary>Available methods</summary>

### [Compute](docs/sdks/compute/README.md)

* [lucidHeartbeat](docs/sdks/compute/README.md#lucidheartbeat) - Submit compute node heartbeat
* [lucidGetHealth](docs/sdks/compute/README.md#lucidgethealth) - Get compute node health

### [Epochs](docs/sdks/epochs/README.md)

* [lucidGetCurrentEpoch](docs/sdks/epochs/README.md#lucidgetcurrentepoch) - Get current epoch
* [lucidListEpochs](docs/sdks/epochs/README.md#lucidlistepochs) - List epochs
* [lucidCreateEpoch](docs/sdks/epochs/README.md#lucidcreateepoch) - Create epoch
* [lucidGetEpoch](docs/sdks/epochs/README.md#lucidgetepoch) - Get epoch
* [lucidRetryEpoch](docs/sdks/epochs/README.md#lucidretryepoch) - Retry failed epoch
* [lucidVerifyEpoch](docs/sdks/epochs/README.md#lucidverifyepoch) - Verify epoch anchor
* [lucidGetEpochTransaction](docs/sdks/epochs/README.md#lucidgetepochtransaction) - Get epoch anchoring transaction
* [lucidCommitEpochRoot](docs/sdks/epochs/README.md#lucidcommitepochroot) - Commit epoch root
* [lucidCommitEpochRootsBatch](docs/sdks/epochs/README.md#lucidcommitepochrootsbatch) - Commit multiple epoch roots
* [lucidGetAnchoringHealth](docs/sdks/epochs/README.md#lucidgetanchoringhealth) - Anchoring service health
* [lucidListEpochsReady](docs/sdks/epochs/README.md#lucidlistepochsready) - Get epochs ready for finalization
* [lucidGetEpochStats](docs/sdks/epochs/README.md#lucidgetepochstats) - Epoch statistics

### [Match](docs/sdks/match/README.md)

* [lucidMatchExplain](docs/sdks/match/README.md#lucidmatchexplain) - Evaluate policy against compute/model meta
* [lucidMatch](docs/sdks/match/README.md#lucidmatch) - Match compute for model
* [lucidRoute](docs/sdks/match/README.md#lucidroute) - Plan a route (match + resolve endpoint)

### [Passports](docs/sdks/passports/README.md)

* [lucidCreatePassport](docs/sdks/passports/README.md#lucidcreatepassport) - Create a passport
* [lucidListPassports](docs/sdks/passports/README.md#lucidlistpassports) - List passports
* [lucidGetPassport](docs/sdks/passports/README.md#lucidgetpassport) - Get a passport
* [lucidUpdatePassport](docs/sdks/passports/README.md#lucidupdatepassport) - Update a passport
* [lucidDeletePassport](docs/sdks/passports/README.md#luciddeletepassport) - Delete a passport (soft delete)
* [lucidTriggerPassportSync](docs/sdks/passports/README.md#lucidtriggerpassportsync) - Trigger on-chain sync for a passport
* [lucidListPassportsPendingSync](docs/sdks/passports/README.md#lucidlistpassportspendingsync) - Get passports pending sync
* [lucidGetPassportStats](docs/sdks/passports/README.md#lucidgetpassportstats) - Passport statistics
* [lucidSearchModels](docs/sdks/passports/README.md#lucidsearchmodels) - Search model passports
* [lucidSearchCompute](docs/sdks/passports/README.md#lucidsearchcompute) - Search compute passports

### [Payouts](docs/sdks/payouts/README.md)

* [lucidCalculatePayout](docs/sdks/payouts/README.md#lucidcalculatepayout) - Calculate payout split
* [lucidPayoutFromReceipt](docs/sdks/payouts/README.md#lucidpayoutfromreceipt) - Create payout from receipt token data
* [lucidGetPayout](docs/sdks/payouts/README.md#lucidgetpayout) - Get payout by run_id
* [lucidVerifyPayout](docs/sdks/payouts/README.md#lucidverifypayout) - Verify payout split

### [Receipts](docs/sdks/receipts/README.md)

* [lucidCreateReceipt](docs/sdks/receipts/README.md#lucidcreatereceipt) - Create a receipt
* [lucidGetReceipt](docs/sdks/receipts/README.md#lucidgetreceipt) - Get a receipt
* [lucidVerifyReceipt](docs/sdks/receipts/README.md#lucidverifyreceipt) - Verify a receipt (hash + signature + inclusion)
* [lucidGetReceiptProof](docs/sdks/receipts/README.md#lucidgetreceiptproof) - Get inclusion proof for receipt
* [lucidGetMmrRoot](docs/sdks/receipts/README.md#lucidgetmmrroot) - Get current MMR root
* [lucidGetSignerPubkey](docs/sdks/receipts/README.md#lucidgetsignerpubkey) - Get orchestrator signing public key

### [Run](docs/sdks/run/README.md)

* [lucidRunInference](docs/sdks/run/README.md#lucidruninference) - Run inference (optionally streaming via SSE)
* [lucidChatCompletions](docs/sdks/run/README.md#lucidchatcompletions) - OpenAI-compatible chat completions

</details>
<!-- End Available Resources and Operations [operations] -->

<!-- Start Standalone functions [standalone-funcs] -->
## Standalone functions

All the methods listed above are available as standalone functions. These
functions are ideal for use in applications running in the browser, serverless
runtimes or other environments where application bundle size is a primary
concern. When using a bundler to build your application, all unused
functionality will be either excluded from the final bundle or tree-shaken away.

To read more about standalone functions, check [FUNCTIONS.md](./FUNCTIONS.md).

<details>

<summary>Available standalone functions</summary>

- [`computeLucidGetHealth`](docs/sdks/compute/README.md#lucidgethealth) - Get compute node health
- [`computeLucidHeartbeat`](docs/sdks/compute/README.md#lucidheartbeat) - Submit compute node heartbeat
- [`epochsLucidCommitEpochRoot`](docs/sdks/epochs/README.md#lucidcommitepochroot) - Commit epoch root
- [`epochsLucidCommitEpochRootsBatch`](docs/sdks/epochs/README.md#lucidcommitepochrootsbatch) - Commit multiple epoch roots
- [`epochsLucidCreateEpoch`](docs/sdks/epochs/README.md#lucidcreateepoch) - Create epoch
- [`epochsLucidGetAnchoringHealth`](docs/sdks/epochs/README.md#lucidgetanchoringhealth) - Anchoring service health
- [`epochsLucidGetCurrentEpoch`](docs/sdks/epochs/README.md#lucidgetcurrentepoch) - Get current epoch
- [`epochsLucidGetEpoch`](docs/sdks/epochs/README.md#lucidgetepoch) - Get epoch
- [`epochsLucidGetEpochStats`](docs/sdks/epochs/README.md#lucidgetepochstats) - Epoch statistics
- [`epochsLucidGetEpochTransaction`](docs/sdks/epochs/README.md#lucidgetepochtransaction) - Get epoch anchoring transaction
- [`epochsLucidListEpochs`](docs/sdks/epochs/README.md#lucidlistepochs) - List epochs
- [`epochsLucidListEpochsReady`](docs/sdks/epochs/README.md#lucidlistepochsready) - Get epochs ready for finalization
- [`epochsLucidRetryEpoch`](docs/sdks/epochs/README.md#lucidretryepoch) - Retry failed epoch
- [`epochsLucidVerifyEpoch`](docs/sdks/epochs/README.md#lucidverifyepoch) - Verify epoch anchor
- [`matchLucidMatch`](docs/sdks/match/README.md#lucidmatch) - Match compute for model
- [`matchLucidMatchExplain`](docs/sdks/match/README.md#lucidmatchexplain) - Evaluate policy against compute/model meta
- [`matchLucidRoute`](docs/sdks/match/README.md#lucidroute) - Plan a route (match + resolve endpoint)
- [`passportsLucidCreatePassport`](docs/sdks/passports/README.md#lucidcreatepassport) - Create a passport
- [`passportsLucidDeletePassport`](docs/sdks/passports/README.md#luciddeletepassport) - Delete a passport (soft delete)
- [`passportsLucidGetPassport`](docs/sdks/passports/README.md#lucidgetpassport) - Get a passport
- [`passportsLucidGetPassportStats`](docs/sdks/passports/README.md#lucidgetpassportstats) - Passport statistics
- [`passportsLucidListPassports`](docs/sdks/passports/README.md#lucidlistpassports) - List passports
- [`passportsLucidListPassportsPendingSync`](docs/sdks/passports/README.md#lucidlistpassportspendingsync) - Get passports pending sync
- [`passportsLucidSearchCompute`](docs/sdks/passports/README.md#lucidsearchcompute) - Search compute passports
- [`passportsLucidSearchModels`](docs/sdks/passports/README.md#lucidsearchmodels) - Search model passports
- [`passportsLucidTriggerPassportSync`](docs/sdks/passports/README.md#lucidtriggerpassportsync) - Trigger on-chain sync for a passport
- [`passportsLucidUpdatePassport`](docs/sdks/passports/README.md#lucidupdatepassport) - Update a passport
- [`payoutsLucidCalculatePayout`](docs/sdks/payouts/README.md#lucidcalculatepayout) - Calculate payout split
- [`payoutsLucidGetPayout`](docs/sdks/payouts/README.md#lucidgetpayout) - Get payout by run_id
- [`payoutsLucidPayoutFromReceipt`](docs/sdks/payouts/README.md#lucidpayoutfromreceipt) - Create payout from receipt token data
- [`payoutsLucidVerifyPayout`](docs/sdks/payouts/README.md#lucidverifypayout) - Verify payout split
- [`receiptsLucidCreateReceipt`](docs/sdks/receipts/README.md#lucidcreatereceipt) - Create a receipt
- [`receiptsLucidGetMmrRoot`](docs/sdks/receipts/README.md#lucidgetmmrroot) - Get current MMR root
- [`receiptsLucidGetReceipt`](docs/sdks/receipts/README.md#lucidgetreceipt) - Get a receipt
- [`receiptsLucidGetReceiptProof`](docs/sdks/receipts/README.md#lucidgetreceiptproof) - Get inclusion proof for receipt
- [`receiptsLucidGetSignerPubkey`](docs/sdks/receipts/README.md#lucidgetsignerpubkey) - Get orchestrator signing public key
- [`receiptsLucidVerifyReceipt`](docs/sdks/receipts/README.md#lucidverifyreceipt) - Verify a receipt (hash + signature + inclusion)
- [`runLucidChatCompletions`](docs/sdks/run/README.md#lucidchatcompletions) - OpenAI-compatible chat completions
- [`runLucidRunInference`](docs/sdks/run/README.md#lucidruninference) - Run inference (optionally streaming via SSE)

</details>
<!-- End Standalone functions [standalone-funcs] -->

<!-- Start Retries [retries] -->
## Retries

Some of the endpoints in this SDK support retries.  If you use the SDK without any configuration, it will fall back to the default retry strategy provided by the API.  However, the default retry strategy can be overridden on a per-operation basis, or across the entire SDK.

To change the default retry strategy for a single API call, simply provide a retryConfig object to the call:
```typescript
import { RaijinLabsLucidAi } from "raijin-labs-lucid-ai";

const raijinLabsLucidAi = new RaijinLabsLucidAi();

async function run() {
  const result = await raijinLabsLucidAi.passports.lucidCreatePassport({
    type: "dataset",
    owner: "<value>",
    metadata: {
      "key": "<value>",
      "key1": "<value>",
      "key2": "<value>",
    },
  }, {
    retries: {
      strategy: "backoff",
      backoff: {
        initialInterval: 1,
        maxInterval: 50,
        exponent: 1.1,
        maxElapsedTime: 100,
      },
      retryConnectionErrors: false,
    },
  });

  console.log(result);
}

run();

```

If you'd like to override the default retry strategy for all operations that support retries, you can provide a retryConfig at SDK initialization:
```typescript
import { RaijinLabsLucidAi } from "raijin-labs-lucid-ai";

const raijinLabsLucidAi = new RaijinLabsLucidAi({
  retryConfig: {
    strategy: "backoff",
    backoff: {
      initialInterval: 1,
      maxInterval: 50,
      exponent: 1.1,
      maxElapsedTime: 100,
    },
    retryConnectionErrors: false,
  },
});

async function run() {
  const result = await raijinLabsLucidAi.passports.lucidCreatePassport({
    type: "dataset",
    owner: "<value>",
    metadata: {
      "key": "<value>",
      "key1": "<value>",
      "key2": "<value>",
    },
  });

  console.log(result);
}

run();

```
<!-- End Retries [retries] -->

<!-- Start Error Handling [errors] -->
## Error Handling

[`RaijinLabsLucidAiError`](./src/models/errors/raijinlabslucidaierror.ts) is the base class for all HTTP error responses. It has the following properties:

| Property            | Type       | Description                                                                             |
| ------------------- | ---------- | --------------------------------------------------------------------------------------- |
| `error.message`     | `string`   | Error message                                                                           |
| `error.statusCode`  | `number`   | HTTP response status code eg `404`                                                      |
| `error.headers`     | `Headers`  | HTTP response headers                                                                   |
| `error.body`        | `string`   | HTTP body. Can be empty string if no body is returned.                                  |
| `error.rawResponse` | `Response` | Raw HTTP response                                                                       |
| `error.data$`       |            | Optional. Some errors may contain structured data. [See Error Classes](#error-classes). |

### Example
```typescript
import { RaijinLabsLucidAi } from "raijin-labs-lucid-ai";
import * as errors from "raijin-labs-lucid-ai/models/errors";

const raijinLabsLucidAi = new RaijinLabsLucidAi();

async function run() {
  try {
    const result = await raijinLabsLucidAi.passports.lucidCreatePassport({
      type: "dataset",
      owner: "<value>",
      metadata: {
        "key": "<value>",
        "key1": "<value>",
        "key2": "<value>",
      },
    });

    console.log(result);
  } catch (error) {
    // The base class for HTTP error responses
    if (error instanceof errors.RaijinLabsLucidAiError) {
      console.log(error.message);
      console.log(error.statusCode);
      console.log(error.body);
      console.log(error.headers);

      // Depending on the method different errors may be thrown
      if (error instanceof errors.ErrorResponse) {
        console.log(error.data$.success); // boolean
        console.log(error.data$.error); // string
        console.log(error.data$.message); // string
        console.log(error.data$.errorCode); // string
        console.log(error.data$.details); // any
      }
    }
  }
}

run();

```

### Error Classes
**Primary errors:**
* [`RaijinLabsLucidAiError`](./src/models/errors/raijinlabslucidaierror.ts): The base class for HTTP error responses.
  * [`ErrorResponse`](./src/models/errors/errorresponse.ts): Bad Request.

<details><summary>Less common errors (6)</summary>

<br />

**Network errors:**
* [`ConnectionError`](./src/models/errors/httpclienterrors.ts): HTTP client was unable to make a request to a server.
* [`RequestTimeoutError`](./src/models/errors/httpclienterrors.ts): HTTP request timed out due to an AbortSignal signal.
* [`RequestAbortedError`](./src/models/errors/httpclienterrors.ts): HTTP request was aborted by the client.
* [`InvalidRequestError`](./src/models/errors/httpclienterrors.ts): Any input used to create a request is invalid.
* [`UnexpectedClientError`](./src/models/errors/httpclienterrors.ts): Unrecognised or unexpected error.


**Inherit from [`RaijinLabsLucidAiError`](./src/models/errors/raijinlabslucidaierror.ts)**:
* [`ResponseValidationError`](./src/models/errors/responsevalidationerror.ts): Type mismatch between the data returned from the server and the structure expected by the SDK. See `error.rawValue` for the raw value and `error.pretty()` for a nicely formatted multi-line string.

</details>
<!-- End Error Handling [errors] -->

<!-- Start Server Selection [server] -->
## Server Selection

### Override Server URL Per-Client

The default server can be overridden globally by passing a URL to the `serverURL: string` optional parameter when initializing the SDK client instance. For example:
```typescript
import { RaijinLabsLucidAi } from "raijin-labs-lucid-ai";

const raijinLabsLucidAi = new RaijinLabsLucidAi({
  serverURL: "http://localhost:3001",
});

async function run() {
  const result = await raijinLabsLucidAi.passports.lucidCreatePassport({
    type: "dataset",
    owner: "<value>",
    metadata: {
      "key": "<value>",
      "key1": "<value>",
      "key2": "<value>",
    },
  });

  console.log(result);
}

run();

```
<!-- End Server Selection [server] -->

<!-- Start Custom HTTP Client [http-client] -->
## Custom HTTP Client

The TypeScript SDK makes API calls using an `HTTPClient` that wraps the native
[Fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API). This
client is a thin wrapper around `fetch` and provides the ability to attach hooks
around the request lifecycle that can be used to modify the request or handle
errors and response.

The `HTTPClient` constructor takes an optional `fetcher` argument that can be
used to integrate a third-party HTTP client or when writing tests to mock out
the HTTP client and feed in fixtures.

The following example shows how to use the `"beforeRequest"` hook to to add a
custom header and a timeout to requests and how to use the `"requestError"` hook
to log errors:

```typescript
import { RaijinLabsLucidAi } from "raijin-labs-lucid-ai";
import { HTTPClient } from "raijin-labs-lucid-ai/lib/http";

const httpClient = new HTTPClient({
  // fetcher takes a function that has the same signature as native `fetch`.
  fetcher: (request) => {
    return fetch(request);
  }
});

httpClient.addHook("beforeRequest", (request) => {
  const nextRequest = new Request(request, {
    signal: request.signal || AbortSignal.timeout(5000)
  });

  nextRequest.headers.set("x-custom-header", "custom value");

  return nextRequest;
});

httpClient.addHook("requestError", (error, request) => {
  console.group("Request Error");
  console.log("Reason:", `${error}`);
  console.log("Endpoint:", `${request.method} ${request.url}`);
  console.groupEnd();
});

const sdk = new RaijinLabsLucidAi({ httpClient: httpClient });
```
<!-- End Custom HTTP Client [http-client] -->

<!-- Start Debugging [debug] -->
## Debugging

You can setup your SDK to emit debug logs for SDK requests and responses.

You can pass a logger that matches `console`'s interface as an SDK option.

> [!WARNING]
> Beware that debug logging will reveal secrets, like API tokens in headers, in log messages printed to a console or files. It's recommended to use this feature only during local development and not in production.

```typescript
import { RaijinLabsLucidAi } from "raijin-labs-lucid-ai";

const sdk = new RaijinLabsLucidAi({ debugLogger: console });
```

You can also enable a default debug logger by setting an environment variable `RAIJINLABSLUCIDAI_DEBUG` to true.
<!-- End Debugging [debug] -->

<!-- Placeholder for Future Speakeasy SDK Sections -->

# Development

## Maturity

This SDK is in beta, and there may be breaking changes between versions without a major version update. Therefore, we recommend pinning usage
to a specific package version. This way, you can install the same version each time without breaking changes unless you are intentionally
looking for the latest version.

## Contributions

While we value open-source contributions to this SDK, this library is generated programmatically. Any manual changes added to internal files will be overwritten on the next generation. 
We look forward to hearing your feedback. Feel free to open a PR or an issue with a proof of concept and we'll do our best to include it in a future release. 

### SDK Created by [Speakeasy](https://www.speakeasy.com/?utm_source=raijin-labs-lucid-ai&utm_campaign=typescript)
